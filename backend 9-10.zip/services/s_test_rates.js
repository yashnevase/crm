const db = require('../lib/dbconnection');

async function createTestRate(row) {
    const sql = `INSERT INTO test_rates (client_id, center_id, insurer_id, test_id, rate, discount_percentage, effective_from, effective_to, is_active, created_by, created_at, updated_at)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())`;
    const params = [row.client_id, row.center_id, row.insurer_id || null, row.test_id, row.rate, row.discount_percentage || 0, row.effective_from, row.effective_to || null, row.is_active ?? 1, row.created_by || null];
    const result = await db.query(sql, params);
    return result.insertId;
}

async function listTestRates() { return db.query('SELECT * FROM test_rates'); }
async function getTestRate(id) { const r = await db.query('SELECT * FROM test_rates WHERE id = ?', [id]); return r[0]; }
async function updateTestRate(id, updates) {
    const fields = []; const values = [];
    Object.entries(updates).forEach(([k, v]) => { if (v !== undefined) { fields.push(`${k} = ?`); values.push(v); } });
    if (!fields.length) return 0;
    const sql = `UPDATE test_rates SET ${fields.join(', ')}, updated_at = NOW() WHERE id = ?`;
    values.push(id); const result = await db.query(sql, values); return result.affectedRows;
}
async function deleteTestRate(id) { const result = await db.query('DELETE FROM test_rates WHERE id = ?', [id]); return result.affectedRows; }

module.exports = { createTestRate, listTestRates, getTestRate, updateTestRate, deleteTestRate };


