const db = require('../lib/dbconnection');

async function createAppointment(row) {
    const sql = `INSERT INTO appointments (case_number, application_number, client_id, center_id, insurer_id, customer_name, customer_mobile, customer_email, customer_address, customer_gps_latitude, customer_gps_longitude, customer_landmark, visit_type, customer_category, appointment_date, appointment_time, confirmed_time, status, assigned_technician_id, assigned_at, assigned_by, customer_arrived_at, medical_started_at, medical_completed_at, remarks, cancellation_reason, created_by, test_name,created_at, updated_at)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?, NOW(), NOW())`;
    const params = [row.case_number, row.application_number || null, row.client_id, row.center_id, row.insurer_id || null, row.customer_name, row.customer_mobile, row.customer_email || null, row.customer_address, row.customer_gps_latitude || null, row.customer_gps_longitude || null, row.customer_landmark || null, row.visit_type, row.customer_category || 'Non_HNI', row.appointment_date, row.appointment_time || null, row.confirmed_time || null, row.status || 'Pending', row.assigned_technician_id || null, row.assigned_at || null, row.assigned_by || null, row.customer_arrived_at || null, row.medical_started_at || null, row.medical_completed_at || null, row.remarks || null, row.cancellation_reason || null, row.created_by || null, row.test_name || null];
    const result = await db.query(sql, params);
    return result.insertId;
}

async function listAppointments({ page = 1, limit = 0, search = '' }) {
    const searchColumns = ['case_number', 'application_number', 'customer_name'];
    const searchParams = [];
    let whereClause = '';

    if (search && search.trim() !== '') {
        const conditions = searchColumns.map(col => `${col} LIKE ?`).join(' OR ');
        whereClause = ` WHERE ${conditions}`;
        searchColumns.forEach(() => searchParams.push(`%${search}%`));
    }

    // Count total records
    const countSql = `SELECT COUNT(*) as total FROM appointments${whereClause ? whereClause + ' AND' : ' WHERE'} is_deleted = 0`;
    const countRows = await db.query(countSql, searchParams);
    const total = countRows[0].total;

    // Paginated records
    let dataSql = `SELECT * FROM appointments${whereClause ? whereClause + ' AND' : ' WHERE'} is_deleted = 0 ORDER BY id DESC`;
    const dataParams = [...searchParams];

    const numericLimit = Number(limit);
    const numericPage = Number(page);

    if (!isNaN(numericLimit) && numericLimit > 0) {
        const offset = (numericPage - 1) * numericLimit;
        dataSql += ` LIMIT ${numericLimit} OFFSET ${offset}`;
    }

    const rows = await db.query(dataSql, dataParams);

    return {
        data: rows,
        pagination: {
            total,
            page: numericPage,
            limit: numericLimit,
            pages: numericLimit > 0 ? Math.ceil(total / numericLimit) : 1,
        },
    };
}



async function getAppointment(id) { const r = await db.query('SELECT * FROM appointments WHERE id = ?', [id]); return r[0]; }

async function updateAppointment(id, updates) {
    const fields = []; const values = [];
    Object.entries(updates).forEach(([k, v]) => { if (v !== undefined) { fields.push(`${k} = ?`); values.push(v); } });
    if (!fields.length) return 0;
    const sql = `UPDATE appointments SET ${fields.join(', ')}, updated_at = NOW() WHERE id = ?`;
    values.push(id);
    const result = await db.query(sql, values); return result.affectedRows;
}

// soft delete appointments
async function softDeleteAppointments(ids) {
  if (!ids.length) return 0;

  const placeholders = ids.map(() => '?').join(', ');
  const sql = `UPDATE appointments SET is_deleted = 1, updated_at = NOW() WHERE id IN (${placeholders})`;

  const result = await db.query(sql, ids);

  return result.affectedRows;
}

async function deleteAppointment(id) { const result = await db.query('DELETE FROM appointments WHERE id = ?', [id]); return result.affectedRows; }




// get specific appointment by diagnostic center

async function listAppointmentsbyDiagnosticCenters({ page = 1, limit = 0, search = '', centerId }) {
    const searchColumns = ['case_number', 'application_number', 'customer_name'];
    const searchParams = [];
    const conditions = [];
    let whereClause = '';


    // Add search condition
    if (search && search.trim() !== '') {
        const searchCondition = searchColumns.map(col => `${col} LIKE ?`).join(' OR ');
        conditions.push(`(${searchCondition})`);
        searchColumns.forEach(() => searchParams.push(`%${search}%`));

    }

    // Add center ID filter
    if (centerId !== undefined && centerId !== null && !isNaN(centerId)) {
        conditions.push(`center_id = ?`);
        searchParams.push(centerId);

    } else {
        console.log('  centerId is invalid or missing — no center_id filter will be applied!');
    }

    // Always exclude deleted records
    conditions.push(`is_deleted = 0`);

    // Combine all into a WHERE clause
    if (conditions.length > 0) {
        whereClause = `WHERE ${conditions.join(' AND ')}`;
    }

    // Count total records
    const countSql = `SELECT COUNT(*) as total FROM appointments ${whereClause}`;

    const countRows = await db.query(countSql, searchParams);
    const total = countRows[0]?.total || 0;

    // Paginated records
    let dataSql = `SELECT * FROM appointments ${whereClause} ORDER BY id DESC`;
    const dataParams = [...searchParams];

    const numericLimit = Number(limit);
    const numericPage = Number(page);

    if (!isNaN(numericLimit) && numericLimit > 0) {
        const offset = (numericPage - 1) * numericLimit;
        dataSql += ` LIMIT ${numericLimit} OFFSET ${offset}`;
    }

    const rows = await db.query(dataSql, dataParams);

    return {
        data: rows,
        pagination: {
            total,
            page: numericPage,
            limit: numericLimit,
            pages: numericLimit > 0 ? Math.ceil(total / numericLimit) : 1,
        },
    };
}



//technician 

async function listAppointmentsbyTechnician({ page = 1, limit = 0, search = '', technicianId }) {
    const searchColumns = ['case_number', 'application_number', 'customer_name'];
    const searchParams = [];
    const conditions = [];
    let whereClause = '';

    // Add search condition
    if (search && search.trim() !== '') {
        const searchCondition = searchColumns.map(col => `${col} LIKE ?`).join(' OR ');
        conditions.push(`(${searchCondition})`);
        searchColumns.forEach(() => searchParams.push(`%${search}%`));
    }

    // Add assigned_technician_id ID filter
    if (technicianId) {
        conditions.push(`assigned_technician_id = ?`);
        searchParams.push(technicianId);
    }

    // Always exclude deleted records
    conditions.push(`is_deleted = 0`);

    // Combine all into a WHERE clause
    if (conditions.length > 0) {
        whereClause = `WHERE ${conditions.join(' AND ')}`;
    }

    // Count total records
    const countSql = `SELECT COUNT(*) as total FROM appointments ${whereClause}`;
    const countRows = await db.query(countSql, searchParams);
    const total = countRows[0]?.total || 0;

    // Paginated records
    let dataSql = `SELECT * FROM appointments ${whereClause} ORDER BY id DESC`;
    const dataParams = [...searchParams];

    const numericLimit = Number(limit);
    const numericPage = Number(page);

    if (!isNaN(numericLimit) && numericLimit > 0) {
        const offset = (numericPage - 1) * numericLimit;
        dataSql += ` LIMIT ${numericLimit} OFFSET ${offset}`;
    }

    const rows = await db.query(dataSql, dataParams);

    return {
        data: rows,
        pagination: {
            total,
            page: numericPage,
            limit: numericLimit,
            pages: numericLimit > 0 ? Math.ceil(total / numericLimit) : 1,
        },
    };
}


// UPDATE BY TECHNICNA OR DIAGNOSTIC IDS
async function UpdateAppointmentsTechnicianDiagnosticCenters(ids, updates) {
  const fields = [];
  const values = [];

  if (updates.center_id !== undefined) {
    fields.push('center_id = ?');
    values.push(updates.center_id);
  }

  if (updates.assigned_technician_id !== undefined) {
    fields.push('assigned_technician_id = ?');
    values.push(updates.assigned_technician_id);
  }

  if (!fields.length) return 0;

  const placeholders = ids.map(() => '?').join(', ');
  const sql = `
    UPDATE appointments
    SET ${fields.join(', ')}, updated_at = NOW()
    WHERE id IN (${placeholders}) AND is_deleted = 0
  `;

  values.push(...ids);

  const result = await db.query(sql, values);
  return result.affectedRows;
}









module.exports = { createAppointment, listAppointments, getAppointment, updateAppointment, deleteAppointment ,softDeleteAppointments , listAppointmentsbyDiagnosticCenters ,listAppointmentsbyTechnician , UpdateAppointmentsTechnicianDiagnosticCenters};


