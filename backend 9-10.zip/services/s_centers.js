const db = require('../lib/dbconnection');

async function createCenter(center) {
    const sql = `INSERT INTO diagnostic_centers (user_id,center_code, center_name, center_type, address, city, state, pincode, contact_number, email, gps_latitude, gps_longitude, letterhead_path, is_active, created_by, created_at, updated_at)
                 VALUES (?,?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())`;
    const params = [center.user_id,center.center_code, center.center_name, center.center_type, center.address, center.city || null, center.state || null, center.pincode || null, center.contact_number || null, center.email || null, center.gps_latitude || null, center.gps_longitude || null, center.letterhead_path || null, center.is_active ?? 1, center.created_by || null];
    const result = await db.query(sql, params);
    return result.insertId;
}

async function listCenters({ page = 1, limit = 0, search = '' }) {
    const searchColumns = ['center_code', 'center_name', 'center_type'];
    const searchParams = [];
    let whereClause = '';

    if (search && search.trim() !== '') {
        const conditions = searchColumns.map(col => `${col} LIKE ?`).join(' OR ');
        whereClause = ` WHERE ${conditions}`;
        searchColumns.forEach(() => searchParams.push(`%${search}%`));
    }

    // Count total records
    const countSql = `SELECT COUNT(*) as total FROM diagnostic_centers${whereClause ? whereClause + ' AND' : ' WHERE'} is_deleted=0`;

    const countRows = await db.query(countSql, searchParams);
    const total = countRows[0].total;

    // Paginated records
    let dataSql = `SELECT * FROM diagnostic_centers${whereClause ? whereClause + ' AND' : ' WHERE'} is_deleted = 0`;
    const dataParams = [...searchParams];

    const numericLimit = Number(limit);
    const numericPage = Number(page);

    if (!isNaN(numericLimit) && numericLimit > 0) {
        const offset = (numericPage - 1) * numericLimit;
        dataSql += ` LIMIT ${numericLimit} OFFSET ${offset}`;
    }

    const rows = await db.query(dataSql, dataParams);

    return {
        data: rows,
        pagination: {
            total,
            page: numericPage,
            limit: numericLimit,
            pages: numericLimit > 0 ? Math.ceil(total / numericLimit) : 1,
        },
    };
}


async function getCenter(id) {
    const rows = await db.query('SELECT * FROM diagnostic_centers WHERE id = ?', [id]);
    return rows[0];
}

async function updateCenter(id, updates) {
    const fields = [];
    const values = [];
    Object.entries(updates).forEach(([key, value]) => {
        if (value !== undefined) {
            fields.push(`${key} = ?`);
            values.push(value);
        }
    });
    if (!fields.length) return 0;
    const sql = `UPDATE diagnostic_centers SET ${fields.join(', ')}, updated_at = NOW() WHERE id = ?`;
    values.push(id);
    const result = await db.query(sql, values);
    return result.affectedRows;
}


//softdelete centers
async function softDeleteCenters(ids) {
  if (!ids.length) return 0;

  const placeholders = ids.map(() => '?').join(', ');
  const sql = `UPDATE diagnostic_centers SET is_deleted = 1, updated_at = NOW() WHERE id IN (${placeholders})`;

  const result = await db.query(sql, ids);

  return result.affectedRows;
}



async function deleteCenter(id) {
    const result = await db.query('DELETE FROM diagnostic_centers WHERE id = ?', [id]);
    return result.affectedRows;
}

module.exports = { createCenter, listCenters, getCenter, updateCenter, deleteCenter ,softDeleteCenters };


