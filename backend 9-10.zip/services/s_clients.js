const db = require('../lib/dbconnection');



async function createClient(client) {
    const sql = `INSERT INTO clients (client_code, client_name, client_type, registered_address, gst_number, pan_number, mode_of_payment, payment_frequency, is_active, created_by, created_at, updated_at)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())`;
    const params = [client.client_code, client.client_name, client.client_type, client.registered_address, client.gst_number || null, client.pan_number || null, client.mode_of_payment || 'Billed_Later', client.payment_frequency || null, client.is_active ?? 1, client.created_by || null];
    const result = await db.query(sql, params);
    return result.insertId;
}

// async function listClients() {
//     return db.query('SELECT * FROM clients');
// }

async function listClients({ page = 1, limit = 0, search = '' }) {
    const searchColumns = ['client_code', 'client_name', 'gst_number'];
    const searchParams = [];
    let whereClause = '';

    if (search && search.trim() !== '') {
        const conditions = searchColumns.map(col => `${col} LIKE ?`).join(' OR ');
        whereClause = ` WHERE ${conditions}`;
        searchColumns.forEach(() => searchParams.push(`%${search}%`));
    }

    // Get total count
    const countSql = `SELECT COUNT(*) as total FROM clients${whereClause ? whereClause + ' AND' : ' WHERE'} is_deleted = 0`;
    const countRows = await db.query(countSql, searchParams);
    const total = countRows[0].total;

    // Validate and sanitize pagination params
    const numericLimit = Number(limit);
    const numericPage = Number(page);
    let dataSql = `SELECT * FROM clients${whereClause ? whereClause + ' AND' : ' WHERE'} is_deleted = 0`;
    const dataParams = [...searchParams];

    if (!isNaN(numericLimit) && numericLimit > 0) {
        const offset = (numericPage - 1) * numericLimit;

        // Interpolate limit and offset directly in SQL
        dataSql += ` LIMIT ${numericLimit} OFFSET ${offset}`;
    }

    // Debugging logs
    // console.log('Final SQL:', dataSql);
    // console.log('Params:', dataParams);

    const rows = await db.query(dataSql, dataParams);

    return {
        data: rows,
        pagination: {
            total,
            page: numericPage,
            limit: numericLimit,
            pages: numericLimit > 0 ? Math.ceil(total / numericLimit) : 1,
        },
    };
}













async function getClient(id) {
    const rows = await db.query('SELECT * FROM clients WHERE id = ?', [id]);
    return rows[0];
}

async function updateClient(id, updates) {
    const fields = [];
    const values = [];
    Object.entries(updates).forEach(([key, value]) => {
        if (value !== undefined) {
            fields.push(`${key} = ?`);
            values.push(value);
        }
    });
    if (fields.length === 0) return 0;
    const sql = `UPDATE clients SET ${fields.join(', ')}, updated_at = NOW() WHERE id = ?`;
    values.push(id);
    const result = await db.query(sql, values);
    return result.affectedRows;
}


// soft delete clients
async function softDeleteClients(ids) {
  if (!ids.length) return 0;

  const placeholders = ids.map(() => '?').join(', ');
  const sql = `UPDATE clients SET is_deleted = 1, updated_at = NOW() WHERE id IN (${placeholders})`;

  const result = await db.query(sql, ids);

  return result.affectedRows;
}


async function deleteClient(id) {
    const result = await db.query('DELETE FROM clients WHERE id = ?', [id]);
    return result.affectedRows;
}

module.exports = { createClient, listClients, getClient, updateClient, deleteClient ,softDeleteClients };


