const db = require('../lib/dbconnection');

async function createTest(row) {
    const sql = `INSERT INTO tests (test_code, test_name, test_type, category_id, description, normal_range_min, normal_range_max, unit, is_active, created_at, updated_at)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())`;
    const params = [row.test_code, row.test_name, row.test_type, row.category_id || null, row.description || null, row.normal_range_min || null, row.normal_range_max || null, row.unit || null, row.is_active ?? 1];
    const result = await db.query(sql, params);
    return result.insertId;
}

async function listTests() { return db.query('SELECT * FROM tests'); }
async function getTest(id) { const r = await db.query('SELECT * FROM tests WHERE id = ?', [id]); return r[0]; }
async function updateTest(id, updates) {
    const fields = []; const values = [];
    Object.entries(updates).forEach(([k, v]) => { if (v !== undefined) { fields.push(`${k} = ?`); values.push(v); } });
    if (!fields.length) return 0;
    const sql = `UPDATE tests SET ${fields.join(', ')}, updated_at = NOW() WHERE id = ?`;
    values.push(id);
    const result = await db.query(sql, values); return result.affectedRows;
}
async function deleteTest(id) { const result = await db.query('DELETE FROM tests WHERE id = ?', [id]); return result.affectedRows; }

module.exports = { createTest, listTests, getTest, updateTest, deleteTest };


