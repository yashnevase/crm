const express = require('express');
const router = express.Router();
const { verifyToken, checkRole } = require('../lib/auth');
const service = require('../services/s_appointments');

const Joi = require('joi');

const appointmentBaseSchema = Joi.object({
    case_number: Joi.string().max(100).required(),
    application_number: Joi.string().max(100).optional().allow(null, ''),
    client_id: Joi.number().optional().allow(null),
    center_id: Joi.number().optional().allow(null),
    insurer_id: Joi.number().optional().allow(null),

    customer_name: Joi.string().max(255).required(),
    customer_mobile: Joi.string().max(20).required(),
    customer_email: Joi.string().email().max(255).optional().allow(null, ''),

    customer_address: Joi.string().required(),
    customer_gps_latitude: Joi.number().precision(8).optional().allow(null),
    customer_gps_longitude: Joi.number().precision(8).optional().allow(null),
    customer_landmark: Joi.string().max(255).optional().allow(null, ''),

    visit_type: Joi.string().valid('Home_Visit', 'Center_Visit').required(),
     test_name: Joi.string().optional(),
    customer_category: Joi.string().valid('HNI', 'Non_HNI').optional(),

    appointment_date: Joi.date().required(),
    appointment_time: Joi.string().pattern(/^\d{2}:\d{2}:\d{2}$/).optional().allow(null),
    confirmed_time: Joi.string().pattern(/^\d{2}:\d{2}:\d{2}$/).optional().allow(null),

    status: Joi.string().valid('Pending', 'Assigned', 'Confirmed', 'In_Progress', 'Completed', 'Partially_Completed', 'Cancelled').optional(),

    assigned_technician_id: Joi.number().optional().allow(null),
    assigned_at: Joi.date().iso().optional().allow(null),
    assigned_by: Joi.number().optional().allow(null),

    customer_arrived_at: Joi.date().iso().optional().allow(null),
    medical_started_at: Joi.date().iso().optional().allow(null),
    medical_completed_at: Joi.date().iso().optional().allow(null),

    remarks: Joi.string().optional().allow(null, ''),
    cancellation_reason: Joi.string().optional().allow(null, ''),

    created_by: Joi.number().optional()
});

const appointmentUpdateSchema = appointmentBaseSchema.fork(
    Object.keys(appointmentBaseSchema.describe().keys),
    field => field.optional()
);

const deleteCentersSchema = Joi.object({
  ids: Joi.array().items(Joi.number().integer().positive()).min(1).required()
});

const bulkUpdateSchema = Joi.object({
  ids: Joi.array().items(Joi.number().integer().positive()).min(1).required(),
  center_id: Joi.number().integer().positive().optional(),
  assigned_technician_id: Joi.number().integer().positive().optional()
}).or('center_id', 'assigned_technician_id'); // at least one is required











router.get('/appointments', verifyToken, async (req, res) => {
    try {
        const page = parseInt(req.query.page) || 1;
        const limit = parseInt(req.query.limit) || 0;
        const search = req.query.q || '';

        const data = await service.listAppointments({ page, limit, search });
        res.json(data);
    } catch (e) {
        console.error('Error listing appointments:', e);
        res.status(500).json({ message: 'Internal server error' });
    }
});

// diagnostic center appointment
router.get('/appointments/DiagnosticCenter', async (req, res) => {
    try {
        const page = parseInt(req.query.page) || 1;
        const limit = parseInt(req.query.limit) || 0;
        const search = req.query.q || '';
        const centerIdRaw = req.query.centerId;
        const centerId = centerIdRaw !== undefined ? parseInt(centerIdRaw) : undefined;

        const data = await service.listAppointmentsbyDiagnosticCenters({ page, limit, search, centerId });
        res.json(data);
    } catch (e) {
        console.error(' Error listing appointments:', e);
        res.status(500).json({ message: 'Internal server error' });
    }
});


// diagnostic center appointment
router.get('/appointments/Technician', async (req, res) => {
    try {
        const page = parseInt(req.query.page) || 1;
        const limit = parseInt(req.query.limit) || 0;
        const search = req.query.q || '';
        const technicianId = parseInt(req.query.technicianId); // or req.params.id if using dynamic route

        const data = await service.listAppointmentsbyTechnician({ page, limit, search, technicianId });
        res.json(data);
    } catch (e) {
        console.error('Error listing appointments:', e);
        res.status(500).json({ message: 'Internal server error' });
    }
});



router.get('/appointments/:id', verifyToken, async (req, res) => { try { const row = await service.getAppointment(req.params.id); if (!row) return res.status(404).json({ message: 'Not found' }); res.json(row); } catch (e) { res.status(500).json({ message: 'Internal server error' }); } });


// router.post('/appointments', verifyToken, checkRole([1]), async (req, res) => { try { const id = await service.createAppointment({ ...req.body, created_by: req.user.id }); res.status(201).json({ id }); } catch (e) { res.status(500).json({ message: 'Internal server error' }); } });

router.post('/appointments', verifyToken, checkRole([1]), async (req, res) => {
    try {
        const { error, value } = appointmentBaseSchema.validate(req.body);
        if (error) return res.status(400).json({ message: error.details[0].message });

        const id = await service.createAppointment({ ...value, created_by: req.user.id });
        res.status(201).json({ id });
    } catch (e) {
        console.error('Create appointment error:', e);
        res.status(500).json({ message: 'Internal server error' });
    }
});




// router.put('/appointments/:id', verifyToken, checkRole([1]), async (req, res) => { try { const affected = await service.updateAppointment(req.params.id, req.body); if (!affected) return res.status(404).json({ message: 'Not found' }); res.json({ updated: affected }); } catch (e) { res.status(500).json({ message: 'Internal server error' }); } });


router.put('/appointments/:id', verifyToken, checkRole([1,3,4]), async (req, res) => {
    try {
        const { error, value } = appointmentUpdateSchema.validate(req.body);
        if (error) return res.status(400).json({ message: error.details[0].message });

        const affected = await service.updateAppointment(req.params.id, value);
        if (!affected) return res.status(404).json({ message: 'Not found or no changes' });

        res.json({ updated: affected });
    } catch (e) {
        console.error('Update appointment error:', e);
        res.status(500).json({ message: 'Internal server error' });
    }
})


// softdelete
router.post('/appointments/delete', verifyToken, checkRole([1]), async (req, res) => {
  const { error, value } = deleteCentersSchema.validate(req.body);
  if (error) return res.status(400).json({ message: error.details[0].message });

  const affected = await service.softDeleteAppointments(value.ids);
  if (!affected) {
    return res.status(404).json({ message: 'No Appointments were found or already deleted' });
  }

  res.json({ message: 'Appointments soft deleted successfully', updated: affected });
});


router.delete('/appointments/:id', verifyToken, checkRole([1]), async (req, res) => { try { const affected = await service.deleteAppointment(req.params.id); if (!affected) return res.status(404).json({ message: 'Not found' }); res.json({ deleted: affected }); } catch (e) { res.status(500).json({ message: 'Internal server error' }); } });



// update technican or diagnostic center ids
router.post('/appointments/UpdateIds', verifyToken, checkRole([1,3,4]), async (req, res) => {
  try {
    const { error, value } = bulkUpdateSchema.validate(req.body);
    if (error) return res.status(400).json({ message: error.details[0].message });

    const affected = await service.UpdateAppointmentsTechnicianDiagnosticCenters(value.ids, {
      center_id: value.center_id,
      assigned_technician_id: value.assigned_technician_id
    });

    if (!affected) return res.status(404).json({ message: 'No appointments updated' });

    res.json({ message: 'Appointments updated successfully', updated: affected });
  } catch (e) {
    console.error('Bulk update error:', e);
    res.status(500).json({ message: 'Internal server error' });
  }
});



////////////////////////////////////////////////  UPLOAD API ////////////////////////////////////////////////


const multer = require('multer');
const xlsx = require('xlsx');
const upload = multer({ dest: 'uploads/' });


// function cleanValue(value) {
//     return value === undefined ? null : value;
// }

function cleanValue(value) {
    if (value === undefined || value === null || value === '') return null;

    // If it's a JS Date
    if (Object.prototype.toString.call(value) === '[object Date]' && !isNaN(value)) {
        return value.toISOString().split('T')[0]; // YYYY-MM-DD
    }

    // If it's an Excel serial number (e.g. 45967)
    if (typeof value === 'number' && value > 30000 && value < 60000) {
        // Convert Excel serial date to JS date
        const excelEpoch = new Date(1899, 11, 30); // Excel's base date
        const date = new Date(excelEpoch.getTime() + value * 86400000);
        return date.toISOString().split('T')[0]; // YYYY-MM-DD
    }

    // Return as-is (could be string, number, etc.)
    return value;
}



function cleanTimeValue(value) {
    if (value === undefined || value === null || value === '') return null;

    // If it's a Date object (Excel gives times as 1899-12-30 + time offset)
    if (Object.prototype.toString.call(value) === '[object Date]' && !isNaN(value)) {
        return value.toTimeString().split(' ')[0]; // HH:MM:SS
    }

    // If it's a number (Excel serial time like 0.5 = 12:00:00)
    if (typeof value === 'number' && value > 0 && value < 1) {
        const totalSeconds = Math.round(value * 24 * 60 * 60);
        const hours = String(Math.floor(totalSeconds / 3600)).padStart(2, '0');
        const minutes = String(Math.floor((totalSeconds % 3600) / 60)).padStart(2, '0');
        const seconds = String(totalSeconds % 60).padStart(2, '0');
        return `${hours}:${minutes}:${seconds}`;
    }

    // If it's a string already in HH:MM:SS or HH:MM
    if (typeof value === 'string') {
        const parts = value.split(':');
        if (parts.length >= 2) {
            const h = parts[0].padStart(2, '0');
            const m = parts[1].padStart(2, '0');
            const s = parts[2] ? parts[2].padStart(2, '0') : '00';
            return `${h}:${m}:${s}`;
        }
    }

    return null;
}




router.post('/appointments/upload', verifyToken, checkRole([1]), upload.single('file'), async (req, res) => {
    try {
        const workbook = xlsx.readFile(req.file.path);
        const sheet = workbook.Sheets[workbook.SheetNames[0]];
        const rows = xlsx.utils.sheet_to_json(sheet);

        // console.log('Parsed rows from Excel:', rows);

        const insertedIds = [];

        for (const row of rows) {
            // Clean data for optional fields
            const cleanedRow = {
                case_number: cleanValue(row.case_number),
                application_number: cleanValue(row.application_number),
                client_id: cleanValue(row.client_id),
                center_id: cleanValue(row.center_id),
                insurer_id: cleanValue(row.insurer_id),

                customer_name: cleanValue(row.customer_name),
                customer_mobile: cleanValue(row.customer_mobile),
                customer_email: cleanValue(row.customer_email),

                customer_address: cleanValue(row.customer_address),
                customer_gps_latitude: cleanValue(row.customer_gps_latitude),
                customer_gps_longitude: cleanValue(row.customer_gps_longitude),
                customer_landmark: cleanValue(row.customer_landmark),

                visit_type: row.visit_type || 'Home_Visit',
                customer_category: row.customer_category || 'Non_HNI',

                appointment_date: cleanValue(row.appointment_date),
                appointment_time: cleanTimeValue(row.appointment_time),
                confirmed_time: cleanTimeValue(row.confirmed_time),

                status: row.status || 'Pending',

                assigned_technician_id: cleanValue(row.assigned_technician_id),
                assigned_at: cleanValue(row.assigned_at),
                assigned_by: cleanValue(row.assigned_by),

                customer_arrived_at: cleanValue(row.customer_arrived_at),
                medical_started_at: cleanValue(row.medical_started_at),
                medical_completed_at: cleanValue(row.medical_completed_at),

                remarks: cleanValue(row.remarks),
                cancellation_reason: cleanValue(row.cancellation_reason),

                created_by: req.user.id
            };


            const id = await service.createAppointment(cleanedRow);
            insertedIds.push(id);
        }

        res.status(201).json({ message: `${insertedIds.length} appointments inserted`, insertedIds });
    } catch (e) {
        console.error('Excel upload error:', e);
        res.status(500).json({ message: 'Failed to process Excel file' });
    }
});



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////












module.exports = router;


