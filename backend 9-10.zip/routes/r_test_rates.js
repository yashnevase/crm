const express = require('express');
const router = express.Router();
const { verifyToken, checkRole } = require('../lib/auth');
const service = require('../services/s_test_rates');

router.get('/test-rates', verifyToken, async (req, res) => { try { res.json(await service.listTestRates()); } catch (e) { res.status(500).json({ message: 'Internal server error' }); } });
router.get('/test-rates/:id', verifyToken, async (req, res) => { try { const row = await service.getTestRate(req.params.id); if (!row) return res.status(404).json({ message: 'Not found' }); res.json(row); } catch (e) { res.status(500).json({ message: 'Internal server error' }); } });
router.post('/test-rates', verifyToken, checkRole([1]), async (req, res) => { try { const id = await service.createTestRate({ ...req.body, created_by: req.user.id }); res.status(201).json({ id }); } catch (e) { res.status(500).json({ message: 'Internal server error' }); } });
router.put('/test-rates/:id', verifyToken, checkRole([1]), async (req, res) => { try { const affected = await service.updateTestRate(req.params.id, req.body); if (!affected) return res.status(404).json({ message: 'Not found' }); res.json({ updated: affected }); } catch (e) { res.status(500).json({ message: 'Internal server error' }); } });
router.delete('/test-rates/:id', verifyToken, checkRole([1]), async (req, res) => { try { const affected = await service.deleteTestRate(req.params.id); if (!affected) return res.status(404).json({ message: 'Not found' }); res.json({ deleted: affected }); } catch (e) { res.status(500).json({ message: 'Internal server error' }); } });

module.exports = router;


