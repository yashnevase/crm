const express = require('express');
const router = express.Router();
const { verifyToken, checkRole } = require('../lib/auth');
const service = require('../services/s_tests');

router.get('/tests', verifyToken, async (req, res) => { try { res.json(await service.listTests()); } catch (e) { res.status(500).json({ message: 'Internal server error' }); } });
router.get('/tests/:id', verifyToken, async (req, res) => { try { const row = await service.getTest(req.params.id); if (!row) return res.status(404).json({ message: 'Not found' }); res.json(row); } catch (e) { res.status(500).json({ message: 'Internal server error' }); } });
router.post('/tests', verifyToken, checkRole([1]), async (req, res) => { try { const id = await service.createTest(req.body); res.status(201).json({ id }); } catch (e) { res.status(500).json({ message: 'Internal server error' }); } });
router.put('/tests/:id', verifyToken, checkRole([1]), async (req, res) => { try { const affected = await service.updateTest(req.params.id, req.body); if (!affected) return res.status(404).json({ message: 'Not found' }); res.json({ updated: affected }); } catch (e) { res.status(500).json({ message: 'Internal server error' }); } });
router.delete('/tests/:id', verifyToken, checkRole([1]), async (req, res) => { try { const affected = await service.deleteTest(req.params.id); if (!affected) return res.status(404).json({ message: 'Not found' }); res.json({ deleted: affected }); } catch (e) { res.status(500).json({ message: 'Internal server error' }); } });

module.exports = router;


