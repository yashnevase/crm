const express = require('express');
const router = express.Router();
const { verifyToken, checkRole } = require('../lib/auth');
const service = require('../services/s_centers');
const Joi = require('joi');

const centerJoiSchema = Joi.object({
  center_code: Joi.string().max(50).required(),
  center_name: Joi.string().max(255).required(),
  center_type: Joi.string().valid('Own', 'Third_Party').required(),
  user_id: Joi.number().integer().optional(),
  address: Joi.string().required(),

  city: Joi.string().max(100).optional().allow(null, ''),
  state: Joi.string().max(100).optional().allow(null, ''),
  pincode: Joi.string().max(10).optional().allow(null, ''),

  contact_number: Joi.string().max(20).optional().allow(null, ''),
  email: Joi.string().email().max(255).optional().allow(null, ''),

  gps_latitude: Joi.number().precision(8).optional().allow(null),
  gps_longitude: Joi.number().precision(8).optional().allow(null),

  letterhead_path: Joi.string().max(500).optional().allow(null, ''),

  is_active: Joi.number().valid(0, 1).optional(),



});

const centerUpdateJoi = Joi.object({
  center_code: Joi.string().max(50).optional(),
  center_name: Joi.string().max(255).optional(),
  center_type: Joi.string().valid('Own', 'Third_Party').optional(),
  user_id: Joi.number().integer().optional(),
  address: Joi.string().optional(),

  city: Joi.string().max(100).optional().allow(null, ''),
  state: Joi.string().max(100).optional().allow(null, ''),
  pincode: Joi.string().max(10).optional().allow(null, ''),

  contact_number: Joi.string().max(20).optional().allow(null, ''),
  email: Joi.string().email().max(255).optional().allow(null, ''),

  gps_latitude: Joi.number().precision(8).optional().allow(null),
  gps_longitude: Joi.number().precision(8).optional().allow(null),

  letterhead_path: Joi.string().max(500).optional().allow(null, ''),

  is_active: Joi.number().valid(0, 1).optional(),
  is_deleted: Joi.number().valid(1).optional(),
})

const deleteCentersSchema = Joi.object({
  ids: Joi.array().items(Joi.number().integer().positive()).min(1).required()
});




router.get('/centers', verifyToken, async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 0; // zero  for complete res
    const search = req.query.q || '';

    const data = await service.listCenters({ page, limit, search });
    res.json(data);
  } catch (e) {
    console.error('Error listing centers:', e);
    res.status(500).json({ message: 'Internal server error' });
  }
});


router.get('/centers/:id', verifyToken, async (req, res) => {
  try {
    const row = await service.getCenter(req.params.id);
    if (!row) return res.status(404).json({ message: 'Center not found' });
    res.json(row);
  } catch (e) {
    console.error('Error getting center:', e);
    res.status(500).json({ message: 'Internal server error' });
  }
});

router.post('/centers', verifyToken, checkRole([1]), async (req, res) => {
  try {
    const { error, value } = centerJoiSchema.validate(req.body);
    if (error) {
      return res.status(400).json({ message: error.details[0].message });
    }

    const id = await service.createCenter({ ...value, created_by: req.user.id });
    res.status(201).json({ message: 'Diagnostic Center created successfully', id });
  } catch (e) {
    console.error('Error creating center:', e);
    if (e.code === 'ER_DUP_ENTRY') {
      res.status(409).json({ message: 'Center code already exists' });
    } else {
      res.status(500).json({ message: 'Internal server error' });
    }
  }
});

router.put('/centers/:id', verifyToken, checkRole([1]), async (req, res) => {
  try {
    const { error, value } = centerUpdateJoi.validate(req.body);
    if (error) {
      return res.status(400).json({ message: error.details[0].message });
    }

    const affected = await service.updateCenter(req.params.id, value);
    if (!affected) return res.status(404).json({ message: 'Center not found or no changes' });

    res.json({ updated: affected });
  } catch (e) {
    console.error('Error updating center:', e);
    if (e.code === 'ER_DUP_ENTRY') {
      res.status(409).json({ message: 'Duplicate center code' });
    } else {
      res.status(500).json({ message: 'Internal server error' });
    }
  }
});

// softdelete
router.post('/centers/delete', verifyToken, checkRole([1]), async (req, res) => {
  const { error, value } = deleteCentersSchema.validate(req.body);
  if (error) return res.status(400).json({ message: error.details[0].message });

  const affected = await service.softDeleteCenters(value.ids);
  if (!affected) {
    return res.status(404).json({ message: 'No centers were found or already deleted' });
  }

  res.json({ message: 'Diagnostic Centers soft deleted successfully', updated: affected });
});





router.delete('/centers/:id', verifyToken, checkRole([1]), async (req, res) => {
  try {
    const affected = await service.deleteCenter(req.params.id);
    if (!affected) return res.status(404).json({ message: 'Center not found' });
    res.json({ deleted: affected });
  } catch (e) {
    console.error('Error deleting center:', e);
    res.status(500).json({ message: 'Internal server error' });
  }
});

module.exports = router;


