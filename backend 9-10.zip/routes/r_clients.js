const express = require('express');
const router = express.Router();
const service = require('../services/s_clients');
const Joi = require('joi');
const { verifyToken, checkRole } = require('../lib/auth');




const registerClientJoi = Joi.object({
  client_code: Joi.string().alphanum().max(20).required(),
  client_name: Joi.string().max(100).required(),
  client_type: Joi.string().valid('Corporate', 'Individual').required(),
  registered_address: Joi.string().max(255).required(),
  gst_number: Joi.string().length(15).optional().allow(null, ''),
  pan_number: Joi.string().length(10).optional().allow(null, ''),
  mode_of_payment: Joi.string().valid('Advance', 'Billed_Later').optional().default('Billed_Later'),
  payment_frequency: Joi.string().valid('Monthly', 'Quarterly', 'Yearly').optional(),
  is_active: Joi.number().valid(0, 1).optional(),
});


const updateClientJoi = Joi.object({
  client_code: Joi.string().alphanum().max(20).optional(),
  client_name: Joi.string().max(100).optional(),
  client_type: Joi.string().valid('Corporate', 'Individual').optional(),
  registered_address: Joi.string().max(255).optional(),
  gst_number: Joi.string().length(15).allow(null, '').optional(),
  pan_number: Joi.string().length(10).allow(null, '').optional(),
  mode_of_payment: Joi.string().valid('Advance', 'Billed_Later').optional(),
  payment_frequency: Joi.string().valid('Monthly', 'Quarterly', 'Yearly').optional(),
  is_active: Joi.number().valid(0, 1).optional(),
});

const deleteCentersSchema = Joi.object({
  ids: Joi.array().items(Joi.number().integer().positive()).min(1).required()
});


router.get('/clients', verifyToken, async (req, res) => {
    try {
        const page = parseInt(req.query.page) || 1;
        const limit = parseInt(req.query.limit) || 0;
        const search = req.query.q || '';

        const data = await service.listClients({ page, limit, search });
        res.json(data);
    } catch (e) {
        console.error('Error listing clients:', e);
        res.status(500).json({ message: 'Internal server error' });
    }
});


router.get('/clients/:id', verifyToken, async (req, res) => {
    try {
        const row = await service.getClient(req.params.id);
        if (!row) return res.status(404).json({ message: 'Not found' });
        res.json(row);
    } catch (e) {
        res.status(500).json({ message: 'Internal server error' });
    }
});

router.post('/clients', verifyToken, checkRole([1]), async (req, res) => {
    try {
        // Validate input
        const { error, value } = registerClientJoi.validate(req.body);
        if (error) {
            return res.status(400).json({ message: error.details[0].message });
        }

        // Call createClient with validated + additional metadata
        const id = await service.createClient({
            ...value,
            created_by: req.user.id // from token
        });

        res.status(201).json({ message: 'Client created successfully', id });

    } catch (e) {
        console.error('Error creating client:', e);

        // Check for duplicate entry error code from MySQL
        if (e.code === 'ER_DUP_ENTRY' && e.sqlMessage.includes('client_code')) {
            return res.status(409).json({ message: 'Client code already exists. Please use a unique client code.' });
        }

        res.status(500).json({ message: 'Internal server error' });
    }
});



router.put('/clients/:id', verifyToken, checkRole([1]), async (req, res) => {
    try {
        const { error, value } = updateClientJoi.validate(req.body);
        if (error) {
            return res.status(400).json({ message: error.details[0].message });
        }
        
        const affected = await service.updateClient(req.params.id, value);
        if (!affected) return res.status(404).json({ message: 'Not found or no changes made' });

        res.json({ updated: affected });
    } catch (e) {
        console.error('Error updating client:', e);
        res.status(500).json({ message: 'Internal server error' });
    }
});

// softdelete
router.post('/clients/delete', verifyToken, checkRole([1]), async (req, res) => {
  const { error, value } = deleteCentersSchema.validate(req.body);
  if (error) return res.status(400).json({ message: error.details[0].message });

  const affected = await service.softDeleteClients(value.ids);
  if (!affected) {
    return res.status(404).json({ message: 'No Clients were found or already deleted' });
  }

  res.json({ message: 'Clients deleted successfully', updated: affected });
});


router.delete('/clients/:id', verifyToken, checkRole([1]), async (req, res) => {
    try {
        const affected = await service.deleteClient(req.params.id);
        if (!affected) return res.status(404).json({ message: 'Not found' });
        res.json({ deleted: affected });
    } catch (e) {
        res.status(500).json({ message: 'Internal server error' });
    }
});

module.exports = router;


